USE [web_DB]
GO

/****** Object:  Table [dbo].[users]    Script Date: 2021-11-25 ���� 8:20:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[users](
	[user_id] [varchar](10) NOT NULL,
	[user_pw] [varchar](100) NULL,
	[user_nm] [varchar](100) NULL,
	[regist_dt] [datetime] NULL,
	[modify_dt] [datetime] NULL,
	[regist_id] [varchar](20) NULL,
	[modify_id] [varchar](20) NULL,
 CONSTRAINT [users_pk] PRIMARY KEY CLUSTERED 
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


