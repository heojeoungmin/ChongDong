package com.coment.service;

import java.util.HashMap;
import java.util.List;

public interface ComentService {
	
	//게시글 조회
	List<HashMap<String, String>> getComentList(HashMap<String, String> pMap);
	//댓글 작성
	int insertComent(HashMap<String, String> pMap);
	
	//댓글 수정
	int updateComent(HashMap<String, String> pMap);
	
	//댓글 삭제
	int deleteComent(HashMap<String, String> pMap);
}