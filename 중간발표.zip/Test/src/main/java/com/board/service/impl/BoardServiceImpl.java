package com.board.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.board.model.BoardMapper;
import com.board.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService {
	//BoardServiceImpl
	
	@Autowired
	BoardMapper boardMapper;
	
	//게시글 목록 조회
	@Override
	public List<HashMap<String, String>> getBoardList(HashMap<String, String> pMap) {
		
		List<HashMap<String, String>> results = boardMapper.selectBoardList(pMap);
		
		return results;
	}
	
	//게시글 조회
	@Override
	public List<HashMap<String, String>> selectBoards(HashMap<String, String> pMap) {
		
		List<HashMap<String, String>> results = boardMapper.selectBoards(pMap);
		
		return results;
	}
	
	//게시글 추가
	@Override
	public int insertBoards(HashMap<String, String> pMap) {
		
		int results = boardMapper.insertBoards(pMap);
		
		return results;
	}
	
	//게시글 수정
	@Override
	public int updateBoards(HashMap<String, String> pMap) {
		
		int results = boardMapper.updateBoards(pMap);
		
		return results;
	}
}
