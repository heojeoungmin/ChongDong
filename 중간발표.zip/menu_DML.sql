USE [web_DB]
GO

/****** Object:  Table [dbo].[menu]    Script Date: 2021-11-25 ���� 8:19:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[menu](
	[menu_id] [varchar](10) NOT NULL,
	[menu_nm] [varchar](100) NULL,
	[menu_url] [varchar](100) NULL,
	[regist_dt] [datetime] NULL,
	[modify_dt] [datetime] NULL,
	[regist_id] [varchar](20) NULL,
	[modify_id] [varchar](20) NULL,
	[use_yn] [varchar](1) NULL,
 CONSTRAINT [menu_pk] PRIMARY KEY CLUSTERED 
(
	[menu_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


