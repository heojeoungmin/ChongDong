USE [web_DB]
GO

/****** Object:  Table [dbo].[boards_comments]    Script Date: 2021-11-25 ���� 8:19:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[boards_comments](
	[menu_id] [varchar](10) NOT NULL,
	[boards_sno] [int] NOT NULL,
	[comments_sno] [int] NOT NULL,
	[contents] [text] NULL,
	[parents_sno] [int] NULL,
	[delete_yn] [varchar](1) NULL,
	[regist_dt] [datetime] NULL,
	[modify_dt] [datetime] NULL,
	[regist_id] [varchar](20) NULL,
	[modify_id] [varchar](20) NULL,
	[sub_parents_sno] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[menu_id] ASC,
	[boards_sno] ASC,
	[comments_sno] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


