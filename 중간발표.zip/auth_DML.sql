USE [web_DB]
GO

/****** Object:  Table [dbo].[auth]    Script Date: 2021-11-25 ���� 8:16:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[auth](
	[sno] [varchar](10) NOT NULL,
	[auth_id] [varchar](10) NULL,
	[user_id] [varchar](100) NULL,
	[regist_dt] [datetime] NULL,
	[modify_dt] [datetime] NULL,
	[regist_id] [varchar](20) NULL,
	[modify_id] [varchar](20) NULL,
 CONSTRAINT [auth_pk] PRIMARY KEY CLUSTERED 
(
	[sno] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


